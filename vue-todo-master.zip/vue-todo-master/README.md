# Vue Todo
Simple Todo application with Vue.js

![Todo screenshot](http://i.imgur.com/Nww9fpM.png)

View demo here: [http://tatthien.github.io/vue-todo/](http://tatthien.github.io/vue-todo/)
